import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assesment',
  templateUrl: './assesment.component.html',
  styleUrls: ['./assesment.component.scss']
})
export class AssesmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

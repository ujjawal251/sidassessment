import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {LoginApi} from '../../utility/LoginApi';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit(): void {
  }

  defaultUser: { email: string, password: string }[] = [
    { "email": "sid@abc.com", "password": "y" },
    { "email": "Ajeet@abc.com", "password": "x" },
    { "email":  "y@abc.com", "password": "z" }
  ];

  OnLoginClick(txtEmail:string, txtPassword:string){
    
    if(txtEmail.length == 0)
    {
      alert("Please enter email.");
      return false;
    }

    if(!this.isValidEmail(txtEmail))
    {
      return false;
    }

    if(txtPassword.length == 0)
    {
      alert("Please enter password.");
      return false;
    }

    var foundCred = this.defaultUser.filter((defaultCred)=>{
      return defaultCred.email === txtEmail && defaultCred.password === txtPassword;
    });
    if(foundCred.length > 0)
    {
      LoginApi.login(txtEmail);
      this.route.navigate(['/', 'landing']);
    }
    else
    {
      alert("login or password do not match.");
      console.log("login or password do not match.");
    }
    return false;
  }

  isValidEmail(txtEmail:string)
  {
    if(txtEmail.length == 0)
    {
      return false;
    }
    var emailReg =  /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    if(!emailReg.test(txtEmail) ){
      alert('Please enter valid email');
      return false;			
    }
    return true;
  }


}

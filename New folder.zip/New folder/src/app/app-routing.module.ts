import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginPageComponent } from './login-page/login-page.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { LogoutPageComponent } from './logout-page/logout-page.component';

const routes: Routes = [
  { 
    path: '', 
    component: LoginPageComponent,
    pathMatch: 'full'
  },
  {path: "landing", component: LandingPageComponent},

  {path: "logout", component: LogoutPageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const routingComponent = [LoginPageComponent, LandingPageComponent, LogoutPageComponent];
class LocalStorageClass {

    LocalStorage(){}

    private stringfyData(data:any) {
        return JSON.stringify(data);
    }

    private parseJsonData(data:string){
        return JSON.parse(data);
    }
    
    saveData(data:any, key: any = "assesments"){
        localStorage.setItem(key, this.stringfyData(data));
    }

    getData(key: string = "assesments"){
        var data = localStorage.getItem(key);
        var parsedData = [];
        if(data)
        {
            parsedData = this.parseJsonData(data);
        }
        return parsedData;
    }

    removeData(key:any){
        localStorage.removeItem(key);
    }
}

export const LocalStorage = new LocalStorageClass();
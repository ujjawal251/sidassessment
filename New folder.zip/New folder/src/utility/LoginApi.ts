import {LocalStorage} from './LocalStorage';

class LoginApiClass{
    LoginClass(){}


    login(email: string){
        if(email){
            LocalStorage.saveData(email, "login");
        }
    }

    logout(){
        LocalStorage.removeData("login");
    }

    getCurrentLogin(){
        return LocalStorage.getData("login")
    }
}

export const LoginApi = new LoginApiClass();
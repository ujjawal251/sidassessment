import {LocalStorage} from './LocalStorage';
import { Assessment } from '../models/assessment'
import { LoginApi } from './LoginApi';
import { Utility } from './Utility'



class AssessmentApiClass{
    //constructor
    AssessmentApiClass(){}

    getAllAssessments(){
        var data = LocalStorage.getData("assesments");
        return this.convertDataArrayToAssessmentArray(data);
    }

    getAssessmentById(assessmentId: string){
        var allAssessments : Assessment[] = this.getAllAssessments();
        var foundAssessmentList: Assessment[] = allAssessments.filter((assessment: Assessment) => { return assessment.id == assessmentId });
        if(foundAssessmentList.length > 0){
            return foundAssessmentList[0];
        }
        return Utility.getDefaultAssessment();
    }

    getActiveAssessments(){
        return this.getActiveInActiveAssessment(1);
    }

    getInActiveAssessments(){
        return this.getActiveInActiveAssessment(0);
    }

    private getActiveInActiveAssessment(isActive: number){
        var allAssessments: Assessment[] = this.getAllAssessments();
        var activeInactiveAssessments: Assessment[] = allAssessments.filter((assessment : Assessment) => { return assessment.isActive == isActive});
        return activeInactiveAssessments;
    }

    getExpiredAssessments(){
        return this.getExpiredOrNotExpiredAssessment(1);
    }

    getNotExpiredAssessments(){
        return this.getExpiredOrNotExpiredAssessment(0);
    }

    private getExpiredOrNotExpiredAssessment(isExpired: number){
        var allAssessments: Assessment[] = this.getAllAssessments();
        var expiredOrNotExpiredAssessments: Assessment[] = allAssessments.filter((assessment : Assessment) => { return assessment.isExpired == isExpired});
        return expiredOrNotExpiredAssessments;
    }

    getPrivateAssessments(){
        var allAssessments: Assessment[] = this.getAllAssessments();
        var currentLogin: string = LoginApi.getCurrentLogin();
        var privateAssessments: Assessment[] = allAssessments.filter((assessment: Assessment) => { return assessment.isArchived == 0 && assessment.createdBy == currentLogin });
        return privateAssessments;
    }

    getActiveInactivePrivateAssessments(isActive: number){
        var allPrivateAssessments: Assessment[] = this.getPrivateAssessments();
        var activeInActivePrivateAssessments : Assessment[] = allPrivateAssessments.filter((assessment: Assessment) => { return assessment.isActive == isActive });
        return activeInActivePrivateAssessments;
    }

    getExpiredOrNotExpiredAssessments(isExpired: number){
        var allPrivateAssessments: Assessment[] = this.getPrivateAssessments();
        var expiredNotExpiredAssessments : Assessment[] = allPrivateAssessments.filter((assessment: Assessment) => { return assessment.isExpired == isExpired });
        return expiredNotExpiredAssessments;
    }

    getAllPrivateAssessmentsWithSearchQuery(searchQuery: string, isAscending: number = 1){
        var allPrivateAssessments: Assessment[] = this.getPrivateAssessments();
        var queriedPrivateAssessment : Assessment[] = allPrivateAssessments.filter((assessment: Assessment) => { return assessment.name.includes(searchQuery) });
        queriedPrivateAssessment = this.sortAssessments(queriedPrivateAssessment, isAscending);
        return queriedPrivateAssessment;
    }

    getActiveOrInActivePrivateAssessmentsWithSearchQuery(isActive: number = 1, searchQuery: string, isAscending: number = 1){
        var activeInactivePrivateAssessments = this.getActiveInactivePrivateAssessments(isActive);
        var queriedActiveInactivePrivateAssessments : Assessment[] = activeInactivePrivateAssessments.filter((assessment: Assessment) => { return assessment.name.includes(searchQuery) });
        queriedActiveInactivePrivateAssessments = this.sortAssessments(queriedActiveInactivePrivateAssessments, isAscending);
        return queriedActiveInactivePrivateAssessments;
    }

    getExpiredOrNotExpiredPrivateAssessmentsWithSearchQuery(isExpired: number = 1, searchQuery: string, isAscending: number = 1){
        var expiredOrNotExpiredPrivateAssessments = this.getActiveInactivePrivateAssessments(isExpired);
        var queriedExpiredOrNotExpiredPrivateAssessments : Assessment[] = expiredOrNotExpiredPrivateAssessments.filter((assessment: Assessment) => { return assessment.name.includes(searchQuery) });
        queriedExpiredOrNotExpiredPrivateAssessments = this.sortAssessments(queriedExpiredOrNotExpiredPrivateAssessments, isAscending);
        return queriedExpiredOrNotExpiredPrivateAssessments;
    }

    getSharedAssessments(){
        var allAssessments: Assessment[] = this.getAllAssessments();
        var currentLogin: string = LoginApi.getCurrentLogin();
        var sharedAssessments: Assessment[] = allAssessments.filter((assessment: Assessment) => { return assessment.sharedTo.includes(currentLogin) });
        return sharedAssessments;
    }

    getSharedAssessmentsWithSearchQuery(searchQuery: string, isAscending: number = 1){
        var sharedAssessments : Assessment[] = this.getSharedAssessments();
        var queriedSharedAssessments : Assessment[] = sharedAssessments.filter((assessment: Assessment) => { return assessment.name.includes(searchQuery) });
        queriedSharedAssessments = this.sortAssessments(queriedSharedAssessments, isAscending);
        return queriedSharedAssessments;
    }

    getArchivedAssessments(){
        var allAssessments: Assessment[] = this.getAllAssessments();
        var currentLogin: string = LoginApi.getCurrentLogin();
        var archivedAssessments: Assessment[] = allAssessments.filter((assessment: Assessment) => { return assessment.isArchived == 1 && assessment.createdBy == currentLogin });
        return archivedAssessments;
    }

    getArchivedAssessmentsWithSearchQuery(searchQuery: string, isAscending: number = 1){
        var archivedAssessments : Assessment[] = this.getArchivedAssessments();
        var queriedArchivedAssessments : Assessment[] = archivedAssessments.filter((assessment: Assessment) => { return assessment.name.includes(searchQuery) });
        queriedArchivedAssessments = this.sortAssessments(queriedArchivedAssessments, isAscending);
        return queriedArchivedAssessments;
    }

    getAllSharedEmailByAssessmentId(assessmentId: string){
        var assessment: Assessment = this.getAssessmentById(assessmentId);
        if(!Utility.IsNullOrEmpty(assessment.sharedTo)){
            var sharedTo: string = assessment.sharedTo;
            return sharedTo.split(";").pop();
        }
        return [];
    }

    shareAssessment(assessmentId: string, email: string){
        var assessment: Assessment = this.getAssessmentById(assessmentId);
        if(!Utility.IsNullOrEmpty(assessment.id)){
            var sharedTo : string = assessment.sharedTo;
            if(!sharedTo.includes(email)){
                sharedTo += email + ";";
            }
            assessment.sharedTo = sharedTo;

            var allAssessments : Assessment[] = this.getAllAssessments();
            allAssessments.forEach(item =>{
                if(item.id == assessment.id){
                    item.sharedTo = assessment.sharedTo;
                }
            });

            this.saveAssessmentsToLocalStorage(allAssessments);
        }
    }

    createAssessment(assessment: Assessment){
        var allAssessments : Assessment[] = this.getAllAssessments();
        allAssessments.push(assessment);
        this.saveAssessmentsToLocalStorage(allAssessments);
    }

    updateAssessment(assessmentId: string, updatedAssessment: Assessment){
        var allAssessments : Assessment[] = this.getAllAssessments();
        allAssessments.forEach(item =>{
            if(item.id == assessmentId){
                item = updatedAssessment
            }
        });
        this.saveAssessmentsToLocalStorage(allAssessments);
    }

    private saveAssessmentsToLocalStorage(assesments: Assessment[]){
        LocalStorage.saveData(assesments, "assesments");
    }

    private sortAssessments(assesments: Assessment[], isAscending: number = 1){
        assesments = assesments.sort((firstAssess, secondAssess) => firstAssess.name.localeCompare(secondAssess.name));
        if(isAscending == 0){
            assesments = assesments.reverse();
        }
        return assesments;
    }

    private convertDataArrayToAssessmentArray(data:[]){
        var assesmentList: Assessment[] = [];
        data.forEach((element : Assessment) => {
            var assessment: Assessment = {id: "", name:"", clientOrg: "", expDate: "", industry: "",
            geography: "", isActive: 1, isExpired: 0, isArchived: 0, createdBy: "", sharedTo: ""};
            element.id != undefined ? assessment.id = element.id : assessment.id = "";
            element.name != undefined ? assessment.name = element.name : assessment.name = "";
            element.clientOrg != undefined ? assessment.clientOrg = element.clientOrg : assessment.clientOrg = "";
            element.expDate != undefined ? assessment.expDate = element.expDate : assessment.expDate = "";
            element.industry != undefined ? assessment.industry = element.industry : assessment.industry = "";
            element.geography != undefined ? assessment.geography = element.geography : assessment.geography = "";
            element.isActive != undefined ? assessment.isActive = element.isActive : assessment.isActive = 1;
            element.isExpired != undefined ? assessment.isExpired = element.isExpired : assessment.isExpired = 0;
            element.isArchived != undefined ? assessment.isArchived = element.isArchived : assessment.isArchived = 0;
            element.createdBy != undefined ? assessment.createdBy = element.createdBy : assessment.createdBy = "";
            element.sharedTo != undefined ? assessment.sharedTo = element.sharedTo : assessment.sharedTo = "";
            assesmentList.push(assessment);
        });
        return assesmentList;
    }
}

export const AssessmentApi = new AssessmentApiClass();
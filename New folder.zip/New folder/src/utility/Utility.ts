import { Assessment } from '../models/assessment'

class UtilityClass{

    UtilityClass(){}

    getNewId(){
        return new Date().valueOf().toString();
    }

    
    IsNullOrEmpty(valueP: any){
        var isNullOrEmpty = true;
        if (valueP)
        {
            if (typeof (valueP) == 'string')
            {
                if (valueP.length > 0)
                    isNullOrEmpty = false;
            }
        }
        return isNullOrEmpty;
    }

    getDefaultAssessment(){
        var assessment: Assessment = {id: "", name:"", clientOrg: "", expDate: "", industry: "",
            geography: "", isActive: 1, isExpired: 0, isArchived: 0, createdBy: "", sharedTo: ""};
        return assessment;
    }
}

export const Utility = new UtilityClass();
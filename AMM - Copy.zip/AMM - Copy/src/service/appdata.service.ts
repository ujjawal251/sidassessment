import { Injectable } from '@angular/core';
import { Assessment } from 'src/models/assessment';

@Injectable({
  providedIn: 'root'
})
export class AppdataService {

  private loggedInUser: string = "";
  private openAssessmentMode: string = "";
  private assessmentData!: Assessment;



  constructor() { }

  getLoggedInUser() {
    return this.loggedInUser;
  }

  setLoggedInUser(loggedInUser: string) {
    this.loggedInUser = loggedInUser;
  }

  getOpenAssessmentMode() {
    return this.openAssessmentMode;
  }

  setOpenAssessmentMode(mode: string) {
    this.openAssessmentMode = mode;
  }

  getAssessmentData() {
    return this.assessmentData;
  }

  setAssessmentData(assesment: any) {
    this.assessmentData = assesment;
  }

  //backend api
  getAllAssessments() {
    //return Assessments;
    var data = this.getData("assesments");
    return data;
  }

  getFilteredAssessments(selectedTab: string = "private", statusType: string = "all", searchText: string = "", isSort: boolean = false) {
    let assesments: Assessment[] = [];
    switch (selectedTab) { case "private": assesments = this.getPrivateAssessments(); break; case "shared": assesments = this.getSharedAssessments(); break; case "archived": assesments = this.getArchivedAssessments(); break; }
    assesments = assesments.filter((assesment: Assessment) => { return (statusType != "all" ? (statusType == "expired" ? this.isAssessmentExpired(assesment) : assesment.status == statusType) : true) && (searchText ? assesment.name.toLowerCase().includes(searchText.toLowerCase()) : true) });
    isSort ? assesments.sort((firstAssess, secondAssess) => firstAssess.name.localeCompare(secondAssess.name)) : assesments;
    return assesments;
  }

  private getPrivateAssessments() {
    var allAssessments: Assessment[] = this.getAllAssessments();
    var currentLogin: string = this.getCurrentLogin();
    var privateAssessments: Assessment[] = allAssessments.filter((assessment: Assessment) => { return assessment.isArchived == 0 && assessment.createdBy == currentLogin });
    return privateAssessments;
  }

  private getSharedAssessments() {
    var allAssessments: Assessment[] = this.getAllAssessments();
    var currentLogin: string = this.getCurrentLogin();
    var sharedAssessments: Assessment[] = allAssessments.filter((assessment: Assessment) => { return assessment.sharedTo.includes(currentLogin) });
    return sharedAssessments;
  }

  private getArchivedAssessments() {
    var allAssessments: Assessment[] = this.getAllAssessments();
    var currentLogin: string = this.getCurrentLogin();
    var archivedAssessments: Assessment[] = allAssessments.filter((assessment: Assessment) => { return assessment.isArchived == 1 && assessment.createdBy == currentLogin });
    return archivedAssessments;
  }

  isAssessmentExpired(assessment: Assessment) {
    if (!this.IsNullOrEmpty(assessment.expDate)) {
      let expiryDate = new Date(assessment.expDate);
      let currentDate = new Date();
      if (expiryDate < currentDate) {
        assessment.isExpired = 1;
        assessment.status = "expired";
        this.updateAssessmentExpiryStatus(assessment);
        return true;
      }
    }
    return false;
  }

  createAssessment(assessment: Assessment) {
    var allAssessments: Assessment[] = this.getAllAssessments();
    allAssessments.push(assessment);
    this.saveData(allAssessments, "assesments");
  }

  getAssessmentById(assessmentId: string) {
    var allAssessments: Assessment[] = this.getAllAssessments();
    var foundAssessmentList: Assessment[] = allAssessments.filter((assessment: Assessment) => { return assessment.id == assessmentId });
    if (foundAssessmentList.length > 0) {
      return foundAssessmentList[0];
    }
    return this.getDefaultAssessment();
  }

  getAllSharedEmailByAssessmentId(assessmentId: string) {
    var assessment: Assessment = this.getAssessmentById(assessmentId);
    if (!this.IsNullOrEmpty(assessment.sharedTo)) {
      var sharedTo: string = assessment.sharedTo;
      return sharedTo.split(";");
    }
    return [];
  }

  shareAssessment(assessmentId: string, email: string) {
    if (!this.IsNullOrEmpty(assessmentId)) {
      var allAssessments: Assessment[] = this.getAllAssessments();
      allAssessments.forEach(item => {
        if (item.id == assessmentId) {
          if (this.IsNullOrEmpty(item.sharedTo)) {
            item.sharedTo = email;
          } else if (!item.sharedTo.includes(email)) {
            item.sharedTo += ";" + email;
          }
          item.sharedBy = this.getCurrentLogin();
        }
      });
      this.saveData(allAssessments, "assesments");
    }
  }

  removeSharedEmailByAssessmentId(assesmentId: string, sharedEmail: string) {
    let allSharedEmail = this.getAllSharedEmailByAssessmentId(assesmentId);
    allSharedEmail = allSharedEmail.filter(item => item !== sharedEmail);
    var allAssessments: Assessment[] = this.getAllAssessments();
    allAssessments.forEach(item => {
      if (item.id == assesmentId) {
        item.sharedTo = allSharedEmail.join(";");
      }
      if (this.IsNullOrEmpty(item.sharedTo)) {
        item.sharedBy = "";
      }
    });
    this.saveData(allAssessments, "assesments");
  }

  archiveAssessment(assesmentId: string) {
    var allAssessments: Assessment[] = this.getAllAssessments();
    allAssessments.forEach(item => {
      if (item.id == assesmentId) {
        item.isArchived = 1;
      }
    });
    this.saveData(allAssessments, "assesments");
  }

  activeInactiveAssessment(assesmentId: string) {
    var allAssessments: Assessment[] = this.getAllAssessments();
    allAssessments.forEach(item => {
      if (item.id == assesmentId) {
        let isActive = 1;
        item.isActive == 1 ? isActive = 0 : isActive = 1;
        item.isActive = isActive;
        item.status = isActive == 0 ? "inactive" : "active";
      }
    });
    this.saveData(allAssessments, "assesments");
  }

  updateAssessment(updatedAssessment: Assessment) {
    var allAssessments: Assessment[] = this.getAllAssessments();
    allAssessments.forEach(item => {
      if (item.id == updatedAssessment.id) {
        item.name = updatedAssessment.name;
        item.clientOrg = updatedAssessment.clientOrg;
        item.expDate = updatedAssessment.expDate;
        item.industry = updatedAssessment.industry;
        item.geography = updatedAssessment.geography;
      }
    });
    this.saveData(allAssessments, "assesments");
  }

  updateAssessmentExpiryStatus(assessment: Assessment) {
    var allAssessments: Assessment[] = this.getAllAssessments();
    allAssessments.forEach(item => {
      if (item.id == assessment.id) {
        if (!this.IsNullOrEmpty(assessment.expDate)) {
          let expiryDate = new Date(assessment.expDate);
          let currentDate = new Date();
          if (expiryDate < currentDate) {
            item.isExpired = 1;
            item.status = "expired";
          }
        }
      }
    });
    this.saveData(allAssessments, "assesments");
  }

  //#region  local storage operation
  private stringfyData(data: any) {
    return JSON.stringify(data);
  }

  private parseJsonData(data: string) {
    return JSON.parse(data);
  }

  saveData(data: any, key: any = 'assesments') {
    localStorage.setItem(key, this.stringfyData(data));
  }

  getData(key: string = 'assesments') {
    var data = localStorage.getItem(key);
    var parsedData = [];
    if (data) {
      parsedData = this.parseJsonData(data);
    }
    return parsedData;
  }

  removeData(key: any) {
    localStorage.removeItem(key);
  }

  //#endregion
  //#region login
  login(email: string) {
    if (email) {
      this.saveData(email, 'login');
    }
  }

  logout() {
    this.removeData('login');
  }

  getCurrentLogin() {
    return this.getData('login');
  }
  //#endregion
  //#region  misc
  getNewId() {
    return new Date().valueOf().toString();
  }

  getDefaultAssessment() {
    var assessment: Assessment = { id: '', name: '', clientOrg: '', expDate: '', industry: '', status: '', geography: '', isActive: 1, isExpired: 0, isArchived: 0, createdBy: '', sharedTo: '', sharedBy: '' };
    return assessment;
  }

  IsNullOrEmpty(valueP: any) {
    var isNullOrEmpty = true;
    if (valueP) {
      if (typeof (valueP) == 'string') {
        if (valueP.length > 0)
          isNullOrEmpty = false;
      }
    }
    return isNullOrEmpty;
  }

  //#endregion

}

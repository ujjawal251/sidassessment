import { Component, OnInit } from '@angular/core';
import { Location } from "@angular/common";
import { Router } from '@angular/router';

import { Assessment } from 'src/models/assessment';
import { AppdataService } from '../../service/appdata.service';

@Component({
  selector: 'app-assesment',
  templateUrl: './assesment.component.html',
  styleUrls: ['./assesment.component.scss']
})
export class AssesmentComponent implements OnInit {

  constructor(private route: Router, private location: Location, private appData: AppdataService) { }

  dropdownList: { id: number, itemName: string }[] = [
    { "id": 1, "itemName": "India" },
    { "id": 2, "itemName": "Singapore" },
    { "id": 3, "itemName": "Australia" },
    { "id": 4, "itemName": "Canada" },
    { "id": 5, "itemName": "South Korea" },
    { "id": 6, "itemName": "Germany" },
    { "id": 7, "itemName": "France" },
    { "id": 8, "itemName": "Russia" },
    { "id": 9, "itemName": "Italy" },
    { "id": 10, "itemName": "Sweden" }
  ];
  selectedItems: { id: number, itemName: string }[] = [];
  dropdownSettings = {};
  loggedInUser: string = "";

  mode: string = "";
  isViewMode: boolean = false;
  assessment: Assessment = {
    id: '',
    name: '',
    clientOrg: '',
    expDate: '',
    industry: '',
    geography: '',
    status: '',
    isActive: 0,
    isExpired: 0,
    isArchived: 0,
    createdBy: '',
    sharedTo: '',
    sharedBy: ''
  };





  ngOnInit() {
    var currentLogin = this.appData.getCurrentLogin();
    if (!currentLogin || currentLogin.length == 0) {
      this.route.navigate(['/', 'login']);
    }
    this.mode = this.appData.getOpenAssessmentMode();
    this.mode == "view" ? this.isViewMode = true : this.isViewMode = false;

    this.dropdownSettings = {
      singleSelection: false,
      text: "Select Geography",
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: "myclass custom-class",
      disabled: this.isViewMode
    };

    if (this.mode != "add") {
      this.assessment = this.appData.getAssessmentData();
      this.setDataToElement("txtAssessmentName", this.assessment.name);
      this.setDataToElement("txtClientOrganization", this.assessment.clientOrg);
      this.setDataToElement("txtAssessmentExpiryDate", this.assessment.expDate);
      this.setDataToElement("txtIndustry", this.assessment.industry);
      this.selectedItems = [];
      let geographyCsv = this.assessment.geography;
      if (geographyCsv) {
        let geographyArray = geographyCsv.split(",");
        geographyArray.forEach((geograhy) => {
          let foundGeographyObject = this.dropdownList.find(obj => { return obj.itemName === geograhy });
          if (foundGeographyObject) {
            this.selectedItems.push(foundGeographyObject);
          }
        });
        if (this.mode == "view") {
          this.disableControl();
        }
      }
    }
  }

  disableControl() {
    (<HTMLInputElement>document.getElementById("txtAssessmentName")).disabled = true;
    (<HTMLInputElement>document.getElementById("txtClientOrganization")).disabled = true;
    (<HTMLInputElement>document.getElementById("txtAssessmentExpiryDate")).disabled = true;
    (<HTMLInputElement>document.getElementById("txtIndustry")).disabled = true;
  }

  setDataToElement(elementId: string, data: any) {
    (<HTMLInputElement>document.getElementById(elementId)).value = data;
  }


  //#region Multiselect method
  onItemSelect(item: any) {
  }
  OnItemDeSelect(item: any) {
  }
  onSelectAll(items: any) {
    this.selectedItems = items;
  }
  onDeSelectAll(items: any) {
    this.selectedItems = [];
  }
  //#endregion

  btnCancelClick() {
    this.location.back();
  }

  btnCreateAssessment(assessmentName: string, clientOrganisationName: string, assessmentExpiryDate: string, industry: string) {
    let defaultAssessment = this.appData.getDefaultAssessment();
    if (this.mode == "add") {
      defaultAssessment.id = this.appData.getNewId();
      defaultAssessment.name = assessmentName;
      defaultAssessment.clientOrg = clientOrganisationName;
      defaultAssessment.expDate = assessmentExpiryDate;
      defaultAssessment.industry = industry;
      defaultAssessment.geography = this.getSelectedGeography();
      defaultAssessment.status = "active";
      defaultAssessment.isActive = 1;
      defaultAssessment.isExpired = 0;
      defaultAssessment.isArchived = 0;
      defaultAssessment.createdBy = this.appData.getCurrentLogin();
      defaultAssessment.sharedTo = "";
      defaultAssessment.sharedBy = "";
      this.appData.createAssessment(defaultAssessment)
    }
    else if (this.mode == "edit") {
      this.assessment.name = assessmentName;
      this.assessment.clientOrg = clientOrganisationName;
      this.assessment.expDate = assessmentExpiryDate;
      this.assessment.industry = industry;
      this.assessment.geography = this.getSelectedGeography();
      this.appData.updateAssessment(this.assessment);
    }
    this.route.navigate(['/', 'dashboard']);
  }

  getSelectedGeography() {
    let selectedGeography: string = "";
    this.selectedItems.forEach((item) => {
      if (selectedGeography.length > 0) {
        selectedGeography = selectedGeography + ",";
      }
      selectedGeography += item.itemName;
    })
    return selectedGeography;
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AstHeaderComponentComponent } from './ast-header-component.component';

describe('AstHeaderComponentComponent', () => {
  let component: AstHeaderComponentComponent;
  let fixture: ComponentFixture<AstHeaderComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AstHeaderComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AstHeaderComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

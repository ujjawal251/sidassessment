import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppdataService } from '../../service/appdata.service';
import { ConfirmationDialogService } from '../confirmbox/confirmbox.service';


@Component({
  selector: 'app-ast-header-component',
  templateUrl: './ast-header-component.component.html',
  styleUrls: ['./ast-header-component.component.scss']
})
export class AstHeaderComponentComponent implements OnInit {

  constructor(private route: Router, private appData: AppdataService, private confirmationDialogService: ConfirmationDialogService) {
    var currentLogin = this.appData.getCurrentLogin();
    this.loggedInUser = currentLogin;
    this.loggedInUserSign = this.loggedInUser.slice(0, 1);
  }

  loggedInUserSign = "";
  loggedInUser = "";

  ngOnInit(): void {
  }

  logoutUser() {
    this.confirmationDialogService.confirm('Logout User', 'Do you really want to logout?', 'Logout', 'Cancel')
      .then((confirmed) => {
        if (confirmed) {
          this.appData.logout();
          this.route.navigate(['/', 'logout']);
        }
      })
      .catch(() => console.log('User dismissed the dialog (e.g., by using ESC, clicking the cross icon, or clicking outside the dialog)'));
  }


}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AstDashboardComponentComponent } from './ast-dashboard-component.component';

describe('AstDashboardComponentComponent', () => {
  let component: AstDashboardComponentComponent;
  let fixture: ComponentFixture<AstDashboardComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AstDashboardComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AstDashboardComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

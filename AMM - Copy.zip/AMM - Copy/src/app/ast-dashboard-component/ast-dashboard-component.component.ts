import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Assessment } from '../../models/assessment';
import { AppdataService } from '../../service/appdata.service';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-ast-dashboard-component',
  templateUrl: './ast-dashboard-component.component.html',
  styleUrls: ['./ast-dashboard-component.component.scss']
})
export class AstDashboardComponentComponent implements OnInit {

  constructor(private route: Router, private appData: AppdataService, public datePipe: DatePipe) { }

  assessments: Assessment[] = this.loadAssessment();
  selectedTypeTab: string = "private";
  selectedStatusType: string = "all";
  searchText: string = "";
  isSortAssessment: boolean = false;

  ngOnInit(): void {
    var currentLogin = this.appData.getCurrentLogin();
    if (!currentLogin || currentLogin.length == 0) {
      this.route.navigate(['/', 'login']);
    }
  }

  typeTabChanged(tabType: string = "private") {
    this.selectedTypeTab = tabType;
    this.loadAssessment();
  }

  assessmentStatusTypeChanged(astStatusType: string = "all") {
    this.selectedStatusType = astStatusType;
    this.loadAssessment();
  }

  assessmentSearchTextChanged(searchText: string = "") {
    this.searchText = searchText;
    this.loadAssessment();
  }

  assessmentSortChaged(isSortAssessment: boolean = false) {
    this.isSortAssessment = isSortAssessment;
    this.loadAssessment();
  }

  onArchivedAssessmentChanged(isArchivedAssessment: boolean = true) {
    this.loadAssessment();
  }


  loadAssessment() {
    let newAssessments: Assessment[] = this.appData.getFilteredAssessments(this.selectedTypeTab, this.selectedStatusType, this.searchText, this.isSortAssessment);
    newAssessments.forEach(assessment => {
      if (!this.appData.IsNullOrEmpty(assessment.expDate)) {
        let expiryDate = new Date(assessment.expDate);
        let currentDate = new Date();
        if (expiryDate < currentDate) {
          assessment.isExpired = 1;
        }
        let archivedDate = expiryDate;
        archivedDate.setDate(expiryDate.getDate() + 90);
        if (archivedDate < currentDate) {
          assessment.isArchived = 1;
        }
      }
    });
    this.assessments = newAssessments;
    return newAssessments;
  }

}

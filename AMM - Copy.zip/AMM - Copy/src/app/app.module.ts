import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule, routingComponent } from './app-routing.module';
import { AppComponent } from './app.component';
import { ConfirmationDialogService } from './confirmbox/confirmbox.service';
import { AppdataService } from '../service/appdata.service';








@NgModule({
  declarations: [
    AppComponent,
    routingComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    AngularMultiSelectModule,
    FormsModule

  ],
  providers: [DatePipe, ConfirmationDialogService],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppdataService } from '../../service/appdata.service';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss']
})
export class LandingPageComponent implements OnInit {

  constructor(private route: Router, private appData: AppdataService) { }

  ngOnInit(): void {
    var currentLogin = this.appData.getCurrentLogin();
    if (!currentLogin || currentLogin.length == 0) {
      this.route.navigate(['/', 'login']);
    }
  }

  goToDashboard() {
    this.route.navigate(['/', 'dashboard']);
  }

}

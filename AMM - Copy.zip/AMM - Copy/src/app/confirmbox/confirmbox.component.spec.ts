import { ComponentFixture, TestBed } from '@angular/core/testing';

import { confirmboxComponent } from './confirmbox.component';

describe('confirmboxComponent', () => {
  let component: confirmboxComponent;
  let fixture: ComponentFixture<confirmboxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ confirmboxComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(confirmboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

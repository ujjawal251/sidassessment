import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ast-share-component',
  templateUrl: './ast-share-component.component.html',
  styleUrls: ['./ast-share-component.component.scss']
})
export class AstShareComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

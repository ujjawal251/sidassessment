import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AstShareComponentComponent } from './ast-share-component.component';

describe('AstShareComponentComponent', () => {
  let component: AstShareComponentComponent;
  let fixture: ComponentFixture<AstShareComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AstShareComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AstShareComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

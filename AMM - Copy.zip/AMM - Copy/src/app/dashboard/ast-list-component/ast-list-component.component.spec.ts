import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AstListComponentComponent } from './ast-list-component.component';

describe('AstListComponentComponent', () => {
  let component: AstListComponentComponent;
  let fixture: ComponentFixture<AstListComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AstListComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AstListComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

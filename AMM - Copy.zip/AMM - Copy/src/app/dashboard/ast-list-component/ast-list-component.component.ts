import { Component, OnInit, OnChanges, SimpleChanges, Input, Output, EventEmitter } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { ModalDismissReasons, NgbCarouselConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Assessment } from '../../../models/assessment';
import { ConfirmationDialogService } from '../../confirmbox/confirmbox.service';
import { AppdataService } from '../../../service/appdata.service';

@Component({
  selector: 'app-ast-list-component',
  templateUrl: './ast-list-component.component.html',
  styleUrls: ['./ast-list-component.component.scss']
})
export class AstListComponentComponent implements OnInit, OnChanges {

  @Input() assessments: Assessment[] = [];
  @Input() selectedTypeTab: string = "";
  @Output() archivedAssessmentChangedEventEmitter = new EventEmitter<boolean>();

  sharedEmails: string[] = []; //["alex.doe@hover.com", "alex.doe2@hover.com"];
  selectedAssessmentId: string = "";

  constructor(private modalService: NgbModal, private appData: AppdataService, private route: Router,
    config: NgbCarouselConfig, public datePipe: DatePipe, private confirmationDialogService: ConfirmationDialogService) { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes["assessments"] != undefined) {
      this.assessments = changes["assessments"].currentValue;
    }
    if (changes["selectedTypeTab"] != undefined) {
      this.selectedTypeTab = changes["selectedTypeTab"].currentValue;
    }
  }

  isValidEmail(txtEmail: string) {
    if (txtEmail.length == 0) {
      alert('Please enter email');
      return false;
    }
    var emailReg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    if (!emailReg.test(txtEmail)) {
      alert('Please enter valid email');
      return false;
    }
    return true;
  }

  shareAssessmentToEmail(email: string) {
    if (this.isValidEmail(email)) {
      this.appData.shareAssessment(this.selectedAssessmentId, email);
      (<HTMLInputElement>document.getElementById("txtEmail")).value = "";
      this.getAllSharedEmail();
    }
  }

  getAllSharedEmail() {
    this.sharedEmails = this.appData.getAllSharedEmailByAssessmentId(this.selectedAssessmentId) as string[];
  }

  removeSharedEmail(sharedEmail: string) {
    this.confirmationDialogService.confirm('Remove Collaborator', 'Do you really want to remove ' + sharedEmail + ' from this Assessment?', 'Remove', 'Cancel')
      .then((confirmed) => {
        if (confirmed) {
          this.appData.removeSharedEmailByAssessmentId(this.selectedAssessmentId, sharedEmail);
          this.getAllSharedEmail();
        }
      })
      .catch(() => console.log('User dismissed the dialog (e.g., by using ESC, clicking the cross icon, or clicking outside the dialog)'));
  }

  closeResult = '';
  open(shareModal: any, assesmentId: string) {
    this.selectedAssessmentId = assesmentId;
    this.getAllSharedEmail();
    this.modalService.open(shareModal, { size: 'size', animation: false, windowClass: "CustomModalFullClass", backdrop: 'static', }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  formatDate(date: string) {
    return this.datePipe.transform(date, "dd MMM yyyy");
  }

  archiveAssessment(assessmentId: string = "") {
    if (assessmentId.length == 0) {
      alert("Assessment id not found.");
    }
    this.confirmationDialogService.confirm('Archive Assessment', 'Do you really want to move this Assessment to archive? \n Participants will no longer be able to access it and this process cannot be undone?', 'Archive', 'Cancel')
      .then((confirmed) => {
        if (confirmed) {
          //archive assessment
          this.appData.archiveAssessment(assessmentId);
          this.archivedAssessmentChangedEventEmitter.emit(true);
        }
      })
      .catch(() => console.log('User dismissed the dialog (e.g., by using ESC, clicking the cross icon, or clicking outside the dialog)'));
  }

  activeInactiveAssessment(assessment: Assessment) {
    if (assessment.id.length == 0) {
      alert("Assessment id not found.");
    }
    if (assessment.isExpired == 1) {
      return;
    }
    let isActiveText: string = assessment.isActive == 1 ? "Inactive" : "Active";
    this.confirmationDialogService.confirm(isActiveText + ' Assessment', 'Do you really want to make this Assessment ' + isActiveText + '?', 'OK', 'Cancel')
      .then((confirmed) => {
        if (confirmed) {
          //archive assessment
          this.appData.activeInactiveAssessment(assessment.id);
          this.archivedAssessmentChangedEventEmitter.emit(true);
        }
      })
      .catch(() => console.log('User dismissed the dialog (e.g., by using ESC, clicking the cross icon, or clicking outside the dialog)'));
  }

  editAssessmentButtonClicked(assesment: Assessment) {
    this.appData.setAssessmentData(assesment);
    let mode = assesment.isExpired == 1 ? "view" : "edit";
    this.appData.setOpenAssessmentMode(mode);
    this.route.navigate(['/', 'assessment']);
  }
}

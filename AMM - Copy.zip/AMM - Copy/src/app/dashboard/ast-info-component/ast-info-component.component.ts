import { Component, OnInit, OnChanges, SimpleChanges, Input } from '@angular/core';

@Component({
  selector: 'app-ast-info-component',
  templateUrl: './ast-info-component.component.html',
  styleUrls: ['./ast-info-component.component.scss']
})
export class AstInfoComponentComponent implements OnInit, OnChanges {

  constructor() { }

  @Input() selectedTypeTab: string = "private";
  showPrivateInfo: boolean = true;
  showArchivedInfo: boolean = true;

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes["selectedTypeTab"] != undefined) {
      this.selectedTypeTab = changes["selectedTypeTab"].currentValue;
    }
    if (this.selectedTypeTab === "private") {
      this.showPrivateInfo = true;
      this.showArchivedInfo = false;
    } else if (this.selectedTypeTab === "archived") {
      this.showArchivedInfo = true;
      this.showPrivateInfo = false;
    }
    else {
      this.showArchivedInfo = false;
      this.showPrivateInfo = false;
    }
  }

}

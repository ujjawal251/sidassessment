import { Component, OnInit, Output, EventEmitter, OnChanges, SimpleChanges, Input } from '@angular/core';
import { Router } from '@angular/router';
import { AppdataService } from '../../../service/appdata.service';

@Component({
  selector: 'app-ast-create-component',
  templateUrl: './ast-create-component.component.html',
  styleUrls: ['./ast-create-component.component.scss']
})
export class AstCreateComponentComponent implements OnInit {

  constructor(private route: Router, private appData: AppdataService) { }

  @Output() assessmentStatusTypeChangeEventEmitter = new EventEmitter<string>();
  @Output() searchTextChagedEventEmitter = new EventEmitter<string>();
  @Output() sortAstChangedEventEmitter = new EventEmitter<boolean>();

  @Input() selectedTypeTab: string = "private";

  searchHasText: boolean = false;
  isSortAssessment: boolean = false;
  showPrivateTabUI: boolean = true;
  astTypeHeader: string = "Assessment List";

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes["selectedTypeTab"] != undefined) {
      this.selectedTypeTab = changes["selectedTypeTab"].currentValue;
    }
    if (this.selectedTypeTab === "private") {
      this.showPrivateTabUI = true;
      this.astTypeHeader == "Assessment List";
    } else {
      this.showPrivateTabUI = false;
    }
    if (this.selectedTypeTab === "shared") {
      this.astTypeHeader = "Shared Assessments"
    } else if (this.selectedTypeTab === "archived") {
      this.astTypeHeader = "Archived Assessments";
    }
  }



  assessmentStatusTypeChanged(selectedType: string = "all") {
    this.assessmentStatusTypeChangeEventEmitter.emit(selectedType);
  }





  createAssessmentClick() {
    this.appData.setOpenAssessmentMode("add");
    this.appData.setAssessmentData(null);
    this.route.navigate(['/', 'assessment']);
  }

  searchAssessments(searchText: string) {
    if (searchText.length > 0) {
      this.searchHasText = true;
    }
    else {
      this.searchHasText = false;
    }
    this.searchTextChagedEventEmitter.emit(searchText);
  }

  sortAssessment() {
    this.isSortAssessment = !this.isSortAssessment;
    this.sortAstChangedEventEmitter.emit(this.isSortAssessment);
  }



}

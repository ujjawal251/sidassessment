import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AstCreateComponentComponent } from './ast-create-component.component';

describe('AstCreateComponentComponent', () => {
  let component: AstCreateComponentComponent;
  let fixture: ComponentFixture<AstCreateComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AstCreateComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AstCreateComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AstTypeComponentComponent } from './ast-type-component.component';

describe('AstTypeComponentComponent', () => {
  let component: AstTypeComponentComponent;
  let fixture: ComponentFixture<AstTypeComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AstTypeComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AstTypeComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

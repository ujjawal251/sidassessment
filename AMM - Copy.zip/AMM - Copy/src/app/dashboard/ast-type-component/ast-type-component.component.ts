import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-ast-type-component',
  templateUrl: './ast-type-component.component.html',
  styleUrls: ['./ast-type-component.component.scss']
})
export class AstTypeComponentComponent implements OnInit {

  constructor() { }

  @Output() tabChangeEventEmitter = new EventEmitter<string>();

  privateToggle = false;

  sharedToggle = true;

  archivedToggle = true;

  ngOnInit(): void {
  }

  tabButtonClicked(tabType: string = "private"){
    if(tabType == "private"){
      this.privateToggle = false;
      this.sharedToggle = true;
      this.archivedToggle = true;
    } else if(tabType == "shared"){
      this.sharedToggle = false;
      this.privateToggle = true;
      this.archivedToggle = true;
    }else if(tabType == "archived"){
      this.archivedToggle = false;
      this.privateToggle = true;
      this.sharedToggle = true;
    }
    this.tabChangeEventEmitter.emit(tabType);
  }

}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginPageComponent } from './login-page/login-page.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { LogoutPageComponent } from './logout-page/logout-page.component';
import { AssesmentComponent } from './assesment/assesment.component';
import { AstTypeComponentComponent } from './dashboard/ast-type-component/ast-type-component.component';
import { AstCreateComponentComponent } from './dashboard/ast-create-component/ast-create-component.component';
import { AstListComponentComponent } from './dashboard/ast-list-component/ast-list-component.component';
import { AstShareComponentComponent } from './dashboard/ast-share-component/ast-share-component.component';
import { AstHeaderComponentComponent } from './ast-header-component/ast-header-component.component';
import { AstDashboardComponentComponent } from './ast-dashboard-component/ast-dashboard-component.component';
import { AstInfoComponentComponent } from './dashboard/ast-info-component/ast-info-component.component';
import { confirmboxComponent } from './confirmbox/confirmbox.component'





const routes: Routes = [
  { 
    path: '', 
    component: LoginPageComponent,
    pathMatch: 'full'
  },
  {path: "login", component: LoginPageComponent},
  {path: "landing", component: LandingPageComponent},
  {path: "logout", component: LogoutPageComponent},
  {path: "assessment", component: AssesmentComponent},
  {path: "dashboard", component: AstDashboardComponentComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const routingComponent = [LoginPageComponent, 
  LandingPageComponent,
  LogoutPageComponent,
  AssesmentComponent,
  AstTypeComponentComponent,
  AstCreateComponentComponent,
  AstListComponentComponent,
  AstShareComponentComponent,
  AstHeaderComponentComponent,
  AstDashboardComponentComponent,
  AstInfoComponentComponent,
  confirmboxComponent,
];
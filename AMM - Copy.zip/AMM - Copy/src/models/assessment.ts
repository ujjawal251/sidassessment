export interface Assessment{
    id: string;
    name: string;
    clientOrg: string;
    expDate: string;
    industry: string;
    geography: string;
    status: string;
    isActive: number;
    isExpired: number;
    isArchived: number;
    createdBy: string;
    sharedTo: string;
    sharedBy: string;
}